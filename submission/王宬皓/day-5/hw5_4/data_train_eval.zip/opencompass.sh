cd opencompass

opencompass ../opencompass_eval.py